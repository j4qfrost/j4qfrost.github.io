#include "stdafx.h"
#include "Menu.h"

Menu::Menu(int boxX, int boxY, int boxW, int boxH)
{
    capacity = 10;
    
	offset = new SDL_Rect;

    offset->x = boxX;
    offset->y = boxY;
    offset->w = 0;
    offset->h = 0;
    
    w = boxW;
    h = boxH;
    
    buttonList = new Button [capacity];
    count = 0;
}

Button* Menu::getButton(int i) const
{
	return (buttonList + i);
}

SDL_Rect* Menu::getOffset() const
{
	return offset;
}

void Menu::addButton(const string& file, bool& flag, const SDL_Surface* destination)
{
    (buttonList + count)->setParams(offset->x,offset->y,w,h,flag,file,destination);

	offset->y += h;
    count++;
}

void Menu::showMenu(Surface& destination)
{
    for(unsigned int i = 0; i < count; i++)
    {
        (buttonList + i)->show(destination);
    }
}

void Menu::handleMenu(const SDL_Event& e)
{
    for(unsigned int i = 0; i < count; i++)
    {
        (buttonList + i)->handleEvent(e);
    }
}

Menu::~Menu()
{
    delete offset;
    delete [] buttonList;
    offset = NULL;
    buttonList = NULL;
}

