#include "stdafx.h"
#include "Button.h"

Button::Button()
{
	count = 0;
	capacity = 5;

	clip = new SDL_Rect;
	clips = new SDL_Rect[capacity];
	swap = NULL;
}

Button::Button(const string& file, const SDL_Surface* destination)
{
    SDL_Surface* loaded = SDL_LoadBMP(file.c_str());
    if (loaded != NULL)
    {
		source = SDL_ConvertSurfaceFormat(loaded, destination->format->format, destination->flags);
		SDL_FreeSurface(loaded);
    }

	count = 0;
	capacity = 5;

	clip = new SDL_Rect;
	clips = new SDL_Rect[capacity];
	swap = NULL;
}

Button::Button(int x, int y, int w, int h, bool& f, const string& file, const SDL_Surface* destination)
{
    bounds.x = x;
    bounds.y = y;
    bounds.w = w;
    bounds.h = h;

	capacity = 5;
	count = 0;

	clips = new SDL_Rect[capacity];
    
    SDL_Surface* loaded = SDL_LoadBMP(file.c_str());
    if (loaded != NULL)
    {
    source = SDL_ConvertSurfaceFormat(loaded, destination->format->format, destination->flags);
	SDL_FreeSurface(loaded);
    } 
    
    addClip(0,0,w,h);
    addClip(w,0,w,h);
    
    clip = &clips[0];
    
    flag = &f;

	swap = NULL;
}

SDL_Surface* Button::getSource() const
{
	return source;
}

void Button::setSource(const string& file, const SDL_Surface* destination)
{
    SDL_Surface* loaded = NULL;
	string ext = file.substr(file.size() - 4);
	if (ext == ".bmp")
		loaded = SDL_LoadBMP(file.c_str());
	else if (ext == ".png")
		loaded = IMG_Load(file.c_str());
	else
		cerr << "Unsupported format!\n";

    if (loaded != NULL)
    {
        source = SDL_ConvertSurfaceFormat(loaded, destination->format->format, destination->flags);
		SDL_FreeSurface(loaded);
    } 
}

void Button::setCoordinates(int x, int y)
{
    bounds.x = x;
    bounds.y = y;
}

void Button::setBounds(int w, int h)
{
    bounds.w = w;
    bounds.h = h;
    
    addClip(0,0,w,h);
    addClip(w,0,w,h);

	clip = &clips[0];
}

void Button::setFlag(bool& f)
{
    flag = &f;
}

void Button::setParams(int x, int y, int w, int h, bool& f, const string& file, const SDL_Surface* destination)
{
    setCoordinates(x,y);
    setBounds(w,h);
    setFlag(f);
    setSource(file,destination);
}



void Button::addClip(int x, int y, int w, int h)
{
    clips[count].x = x;
    clips[count].y = y;
    clips[count].w = w;
    clips[count].h = h;
    
    count++;
}

void Button::addSwap(const string& file)
{
	SDL_Surface* loaded = NULL;
	string ext = file.substr(file.size() - 4);
	if (ext == ".bmp")
		loaded = SDL_LoadBMP(file.c_str());
	else if (ext == ".png")
		loaded = IMG_Load(file.c_str());
	else
		cerr << "Unsupported format!\n";

    if (loaded != NULL)
    {
        swap = SDL_ConvertSurfaceFormat(loaded, source->format->format, source->flags);
		SDL_FreeSurface(loaded);
    } 
}

void Button::handleEvent(const SDL_Event& e)
{
    int x = 0;
    int y = 0;
    
    if (e.type == SDL_MOUSEMOTION)
    {
        x = e.motion.x;
        y = e.motion.y;
        
        if ((x > bounds.x) && (x < bounds.x + bounds.w) &&
                (y > bounds.y) && (y < bounds.y + bounds.h))
            clip = &clips[1];
        else
            clip = &clips[0];
    }
    if (e.type == SDL_MOUSEBUTTONDOWN)
    {
        if (e.button.button == SDL_BUTTON_LEFT)
		{
            x = e.button.x;
            y = e.button.y;

            
            if ((x > bounds.x) && (x < bounds.x + bounds.w) &&
                (y > bounds.y) && (y < bounds.y + bounds.h))
            {
				if (count > 2)
					clip = &clips[2];
                *flag = !(*flag);
            }
		}
    }
}

void Button::show(Surface& destination)
{
    destination.applySurface(bounds.x,bounds.y,((*flag && swap != NULL)? swap:source),clip);
}

Button::~Button()
{
    delete [] clips;
	delete clip;
    delete flag;
    delete source;
    clips = NULL;
	clip = NULL;
	flag = NULL;
	source = NULL;
}