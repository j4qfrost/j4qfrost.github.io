/**
 * Create your Strategy here.
 * Feel free to rename the class, but remember to change the #ifndef and stuff.
 *
 * If you downloaded the novice version, I've provided example code so you can 
 * get a grasp of what's going on. For those of you who are more advanced, feel
 * free to mix it up, but keep in mind that your class has to be a child of the
 * Strategy class. Any additional classes must be packaged neatly together for
 * submission and always try to write clear code, since I need to plug the code
 * into the rest of the project.
 *
 * The cpp hasn't been implemented for this class. This is a guideline for how you
 * should start.
 *
 * Go nuts.
 */

#ifndef STARTERSTRATETGY_H
#define STARTERSTRATETGY_H

#include "Strategy.h"

class StarterStrategy : public Strategy
{
public:
	StarterStrategy();
	StarterStrategy(Snake* dumbSnake, Grid* g);
	~StarterStrategy();

	void runStrategy();
	//Don't add parameters for this function. All you need to do is change what's inside.

private:
	//Only create variables you absolutely need.
};

#endif