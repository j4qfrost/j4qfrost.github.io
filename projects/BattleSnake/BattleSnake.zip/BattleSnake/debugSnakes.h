/**
 *	This page is here to help you setup and run your strategy for testing purposes.
 *	Feel free to use it however you see fit.
 *
 *	I will add helpful hints at your requests. Happy Koding!
 *
*/

#include "Strategy.h" //Change to your custom Strategy child class


void initStrategies(Strategy* &strategies, Grid* g)
{
	//The code is currently designed for two snakes in the Grid.
	//School has been busy, but when I find the time I will add more.
	strategies = new Strategy[2];
	strategies[0].setCobra(g->grabSnake(0));
	strategies[1].setCobra(g->grabSnake(1));
	strategies[0].setGrid(g);
	strategies[1].setGrid(g);
	strategies[0].changeName("asdas");
}

void runStrategies(Strategy* &strategies)
{
	strategies[0].runStrategy();
	strategies[1].runStrategy();
}

void defang(Strategy* &strategies, Grid* g)
{
	strategies[0].burnSnake();
	strategies[1].burnSnake();

	initStrategies(strategies,g);
}
