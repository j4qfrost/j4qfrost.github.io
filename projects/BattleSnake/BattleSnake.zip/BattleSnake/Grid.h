/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Grid.h
*/

#ifndef GRID_H
#define GRID_H

#include "Surface.h"
#include "Snake.h"
#include <ctime>
#include <vector>

class Grid : public Surface
{
public:
	Grid();
	/**
		This constructor was used for inheritance purposes. You likely won't be seeing this later.
	*/

	Grid(SDL_Surface* s, int nSnakes);
	/**
		This constructor is used for main gameplay. Although you don't need to be too concerned with
		the constructors in general, I will explain why I have this constructor and the next one.
	*/

	Grid(SDL_Surface* s, int nSnakes, Uint32 color);
	/**
		This constructor was implemented before the one above. After I decided to mark the snakes
		different colors, I added the above constructor, and left this one for deploying the snake
		drawing in the bottom left of the screen. Note that the snake is white while the snakes in the
		main grid are red and blue. This constructor allows for more flexible color choice. Although,
		you can still change Snake color with setScale. ~see Snake class
	*/

	~Grid();

	bool checkCollision();
	/**
		Checks if any Snake in member snakes has collided. Since I don't want to delete the Snake pointers
		right away, I am going through and marking the ones that collided.

		@return True if any of the Snake pointers collided, false otherwise.
	*/

	Snake* grabSnake(int i) const;
	/**
		Returns the Snake pointer in member snakes at index i. I may modify this function if I switch from
		vector to linked list.

		@param i - Index of the Snake that is going to be returned.
	*/

	unsigned int getSavedSize() const;
	/**
		Returns member savedSize.

		@return "" "" ""
	*/

	void initPixels();
	/**
		Sets the colors in colorType and seeds random number.
	*/

	void drawSnakes();
	/**
		Draws all Snake pointers in member snakes to the inherited SDL_Surface.
	*/

	void moveSnakes();
	/**
		Moves all the Snake coordinates "ahead". More details can be found by reading
		the documentation for the Snake class.
	*/

	void changeDirection(int i, bool right);
	/**
		Changes the direction of teh Snake at index i.

		@param i - Index at which the target Snake can be found.
		@param right - If this is true, then the Snake will move right, if not then it moves left.
	*/

	void growSnake(int i);
	/**
		Grows the Snake at index i.

		@param i - Index at which the target Snake can be found.
	*/

	void dropStuff();
	/**
		Randomly draws blocks to the member surface of the Grid.
	*/

	void clearGrid();
	/**
		Draws a black rectangle over the member surface to clear the Grid graphically. Then, it
		empties the member snakes and adds new Snake pointers.
	*/

	void addSnake(Snake* snake);
	/**
		Adds another Snake pointer to member snakes.

		@param snake - Snake pointer to be added.
	*/

	void throwSnakes();
	/**
		Empties the vector of Snake pointers, snakes.
	*/

private:
	Uint32* colorType; //array of colors used

	int* arenaStart;

	vector<Snake*> snakes; //considering a linked list
	unsigned int savedSize; //saved for respawn
};

#endif