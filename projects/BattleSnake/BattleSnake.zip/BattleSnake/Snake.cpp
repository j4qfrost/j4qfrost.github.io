#include "stdafx.h"
#include "Snake.h"

Snake::Snake()
{
	head = NULL;
	rattle = NULL;

	segmentSize = 10;
	length = 1;
	maxLength = 100;
}

Snake::Snake(int x, int y, SDL_Rect b, unsigned int d, Uint32 color, bool w)
{
	segmentSize = 10;
	length = 1;
	maxLength = 100;
	scale = color;
	direction = d % 4;
	bound = new SDL_Rect;
	*bound = b;

	Node *newNode = new Node;
	newNode->setX(x);
	newNode->setY(y);
	newNode->setPreviousLink(NULL);
	newNode->setNextLink(NULL);

	head = newNode;
	rattle = newNode;
	wrap = w;
	for(int i = 0; i < 10; i++)
	{
		growSnake();
		move();	
	}
}

void Snake::setCoordinates(int x, int y)
{
	Node *newNode = new Node;
	newNode->setX(x);
	newNode->setY(y);
	newNode->setPreviousLink(NULL);
	newNode->setNextLink(NULL);

	head = newNode;
	rattle = newNode;
	for(int i = 0; i < 10; i++)
	{
		growSnake();
		move();	
	}
}

void Snake::setBounds(SDL_Rect b)
{
	bound = new SDL_Rect;
	*bound = b;
}

void Snake::setDirection(unsigned int d)
{
	direction = d % 4;
}

void Snake::setScale(Uint32 color)
{
	scale = color;
}

void Snake::setParams(int x, int y, SDL_Rect b, unsigned int d, Uint32 color)
{
	setBounds(b);
	setDirection(d);
	setCoordinates(x, y);
	setScale(color);
}

void Snake::growSnake()
{
	grow = true;
}

void Snake::move()
{
	if (!(grow && length < maxLength))	
	{
		Node* temp = rattle;
		rattle = rattle->getPreviousLink();
		rattle->setNextLink(NULL);
		delete temp;
		temp = NULL;	 		
	}
	else
	{
		grow = false;
		length++;
	}
	
	Node* newNode = new Node;
	if(direction == 1)
	{
		if(head->getY() > bound->h - 2 * segmentSize && wrap)
		{
			newNode->setY(0);
		}
		else
		{			
			newNode->setY(head->getY() + segmentSize);
		}
		newNode->setX(head->getX());
	}

	else if(direction == 3)
	{	
		if(head->getY() < segmentSize && wrap)
		{
			newNode->setY(bound->h - segmentSize);
		}
		else
		{
			newNode->setY(head->getY() - segmentSize);
		}
		newNode->setX(head->getX());
	}

	else if(direction == 2)
	{
		if(head->getX() > bound->w - 2 * segmentSize && wrap)
		{
			newNode->setX(0);
		}
		else
		{
			newNode->setX(head->getX() + segmentSize);
		}
		newNode->setY(head->getY());
	}
	else									
	{	
		if(head->getX() < segmentSize && wrap)
		{
			newNode->setX(bound->w - segmentSize);
		}
		else
		{
			newNode->setX(head->getX() - segmentSize);
		}
		newNode->setY(head->getY());
	}
	newNode->setPreviousLink(NULL);
	newNode->setNextLink(head);
	head->setPreviousLink(newNode);
	head = newNode;
}


//0 is left
//1 is down
//2 is right
//3 is up
void Snake::moveLeft()
{
	direction = (direction + 1) % 4;
}

void Snake::moveRight()
{
	direction = (direction + 3) % 4;
}

void Snake::drawTile(int x, int y, const Surface* destination, Uint32 color)
{
	SDL_Rect offset;
	offset.w = segmentSize;
	offset.h = segmentSize;
	offset.x = x;
	offset.y = y;
	SDL_FillRect(destination->getSurface(), &offset, color);
}

void Snake::drawSnake(const Surface* destination)
{
	
	if (!init)
	{
		Node* current = head;
		while(current != NULL)
		{
			drawTile(current->getX() + bound->x,current->getY() + bound->y,destination,scale);
			current = current->getNextLink();
		}
		init = true;
	}
	else
	{
		drawTile(head->getX(),head->getY(),destination,scale);
		drawTile(rattle->getPreviousLink()->getX(),rattle->getPreviousLink()->getY(),
			destination,SDL_MapRGB(destination->getSurface()->format,255,255,0));
		drawTile(rattle->getX(),rattle->getY(),destination,0);
		
	}
}

int Snake::checkCollision(const Uint32* colorType, const Surface* s)
{
	Uint32 color = 0;
		
	switch (direction) {
	case 0:
		color = getPixel(s->getSurface(),  head->getX() - segmentSize / 2, head->getY() + segmentSize / 2);
		break;
	case 1:
		color = getPixel(s->getSurface(),  head->getX() + segmentSize / 2, head->getY() + 3 * segmentSize / 2);
		break;
	case 2:
		color = getPixel(s->getSurface(),  head->getX() + 3 * segmentSize / 2, head->getY() + segmentSize / 2);
		break;
	case 3:
		color = getPixel(s->getSurface(),  head->getX() + segmentSize / 2, head->getY() - segmentSize / 2);
		break;
	}

	cout << color << endl;

	if (color == colorType[1] || color == colorType[2] || color == colorType[3])
		return 0;
	else if (color == colorType[4])
		return 1;
	else
		return 2;
}


Node* Snake::getHead() const
{
	return head;
}

Node* Snake::getRattle() const
{
	return rattle;
}

int Snake::getLength() const
{
	return length;
}

int Snake::getDirection() const
{
	return direction;
}

Uint32 Snake::getPixel(const SDL_Surface* s, int x, int y) const
{
	   Uint32* pixels = (Uint32*)s->pixels;

	   x = (x + bound->x + bound->w) % bound->w;
	   y = (y + bound->y + bound->h) % bound->h;

	   return pixels[ (y * s->w) + x ];
}

Uint32 Snake::getScale() const
{
	return scale;
}

SDL_Rect Snake::getLineOfSight() const
{
	SDL_Rect box = SDL_Rect();
	box.w = 10;
	box.h = 10;
	box.x = head->getX();
	box.y = head->getY();
	//switch (direction) {
	//case 0:
	//	box.x -= 10;
	//	break;
	//case 1:
	//	box.y += 10;
	//	break;
	//case 2:
	//	box.x += 10;
	//	break;
	//case 3:
	//	box.y -= 10;
	//	break;
	//}
	return box;
}

void Snake::destroySnake()
{
	Node* current = head->getNextLink();
	Node* trailCurrent = head;
	while(current != NULL)
	{
		delete trailCurrent;
		trailCurrent = current;
		current = current->getNextLink();
	}
	delete trailCurrent;
	trailCurrent = NULL;
	head = NULL;
	rattle = NULL;
}

Snake::~Snake()
{
	destroySnake();
	delete bound;
	bound = NULL;
}
