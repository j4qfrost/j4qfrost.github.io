/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Strategy.h
*/

#ifndef STRATEGY_H
#define STRATEGY_H

#include "Grid.h"

class Strategy
{
public:
	Strategy();
	/**
		This constructor initializes the member name to ...Avoid using it unless 
		creating an array of Strategies. This constructor was mainly created for
		the purpose of inheritance. You will be implementing the children to Strategy.
	*/

	Strategy(Snake* dumbSnake, Grid* g);
	/**
		This constructor sets the member cobra to pointer dumbSnake	and member 
		grid to pointer g. It also sets member name to "Pungi".
		
		@param dumbSnake - Snake to be taught.
		@param g - Grid that dumbSnake is placed in.
		WARNING: You can also set grid to be g that does not contain dumbSnake.
				 This has untested consequences. Your computer may blow up...
	*/

	~Strategy();

	void setCobra(Snake* snake);
	/**
		This sets the member cobra to a new Snake to be manipulated. This was implemented
		so that you could make a dynamic array of Snake objects and still be able to easily
		change the snakes. Since I used a pointer, there won't be an issue with Snake objects
		not responding to changes.

		@param snake - Pointer to a Snake that will be controlled.
	*/

	void setGrid(Grid* g);
	/**
		This sets the member grid to a Grid to gather resources from. I was able
		to come up with some naughty ways to exploit this function, but I haven't
		come up with a fix yet, so for now I will just pre-read your code before
		the competition.

		@param g - Pointer to a Grid that supply resources.
	*/

	Snake* getCobra() const;
	/**
		Returns the Snake object being manipulated.

		@return "" "" ""
	*/

	bool dodge(int direction, bool rightChecked) const;
	/**
		This uses a single recursion to check forward, right, and left for obstacles.
		Return value will be analyzed later. This was implemented to test my idea on
		graphical collision. It is currently being used in the initial version of the code.
		I am keeping it, so that the logo at the bottom left works. Novices should feel free
		to use it. Please note that this algorithm is very basic, and if you use only this in
		your runStrategy() function, you will be crushed. More advanced programmers should
		reimplement this function to figure out how the collision works. Feel free to use this
		as reference.

		@param direction - Initial pass is member direciton of member cobra.
		@param rightChecked - Sees if the block to the right was checked.
		@return Analyze later. Possible use for graph recursion. May consider type int.
	*/

	void runStrategy();
	/**
		This runs the strategy, which is currently set to dodge.
	*/

	void changeName(const string& newName);
	/**
		Don't like the preset Strategy name? Change it.

		@param newName - Do I really have to say it?
	*/

	void burnSnake();
	/**
		Deletes and nullifies the member cobra.
	*/

	string getName() const;
	/**
		Returns the name of the Strategy employed.

		@return "" "" ""
	*/

	Uint32* getPixels() const;
	/**
		Returns an array of pixels that are currently draw on top of the member grid.
		I had tried to simply store this value to a member variable, but it's basically
		useless since the pixels update reuglarly.

		@return "" "" ""
	*/

protected:
	string name; //name of the strategy

private:
	bool resultFlag; //Analyze later
	Snake* cobra; //enlightened snake
	Grid* grid; //playing field
};

#endif