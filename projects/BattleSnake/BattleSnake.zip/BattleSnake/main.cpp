/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * main.cpp
*/

#include "stdafx.h"
//#include "SDL_mixer.h"
#include "SDL_ttf.h"
#include "debugSnakes.h"

using namespace std;

SDL_Event e; // handles main input events
Surface* s = NULL; //main display
Grid* g = NULL; //main grid to be played on
Grid* snakeJar = NULL; //testing/decorative purposes
Menu* menuButton = NULL; //main menu
SDL_Surface* gin = NULL; //reserve surface for grid to be drawn on
SDL_Surface* jar = NULL; // "" "" ""

Strategy* strategies = NULL; //testing default strategy
Strategy* charmer = NULL; //default strategy implemented in snakeJar
SDL_Rect* blocks = new SDL_Rect [33]; //World Domination!!!

TTF_Font* font = NULL; //store font
//SDL_Surface* title = NULL; //title of the game
SDL_Surface* background = NULL;

bool running = true; //runs the main while loop
bool ingame = false; //ture if game is in session
bool selection = false; // UPDATING
bool reset = false; //UPDATING

SDL_Window* window = NULL; //loads window
SDL_Renderer* renderer = NULL; //renders graphics to screen
SDL_Texture* texture = NULL; //texture to be rendered

//Mix_Chunk* bgm = NULL; //Rising - Yoshida Brothers I'll add this for the actual competition. Check the song out on Youtube. It's epic.

bool loadResources(); //unzip and load items for usage
bool initGraphics(); //sets up main surface and grid and initializes test strategies
bool initSound(); //sets up sounds
bool initMenu(); // sets up menu options and testing sandbox

void cleanUp(); //destroys objects
void logo(); //Badassery
int counter = 0; 
int delay = 5;

void loop()
{
	SDL_UpdateTexture(texture, NULL, s->getSurface()->pixels, s->getSurface()->pitch);
		SDL_RenderClear(renderer);
		SDL_RenderCopy(renderer, texture, NULL, NULL);
		SDL_RenderPresent(renderer);
		/* --- UPDATE SCREEN --- */

		snakeJar->drawSnakes();
		if (snakeJar->grabSnake(0)->getLength() < 40)
			snakeJar->grabSnake(0)->growSnake();
		snakeJar->moveSnakes();
		charmer->runStrategy();
		s->applySurface(130,540,snakeJar);
		/* --- SANDBOX --- */

		if (ingame) /* --- INGAME --- */
		{
			ingame = !g->checkCollision();
			
			if (!ingame)
				counter= -1;
			else
			{
				g->drawSnakes();
				g->moveSnakes();
				runStrategies(strategies); //See debugSnake.h
				s->applySurface(508,15,g);
				if (counter == 100)
				{
					g->dropStuff();
					counter = 0;
				}
				counter++;
			}
		}
		else if (counter == -1)
		{
			SDL_Color tColor = {255,255,255};

			int i = 0;

			while(i < 2 && strategies[i].getCobra()->getScale() == 1)
				i++;

			SDL_Surface* winner = NULL;

			if (i < 2)
			{
				winner = TTF_RenderText_Solid(font, (strategies[i].getName() + " wins!").c_str(), tColor);
				
				/* --- DRAW WIN MESSAGE --- */
			}
			else
			{
				winner = TTF_RenderText_Solid(font, "It's a tie!", tColor);
			}

			while(strategies[i].getCobra() == NULL)
				i++;

			g->applySurface(g->getSurface()->w/2-winner->w/2,g->getSurface()->h/2-winner->h/2,winner,&winner->clip_rect);
			s->applySurface(508,15,g);
			SDL_UpdateTexture(texture, NULL, s->getSurface()->pixels, s->getSurface()->pitch);
			SDL_RenderClear(renderer);
			SDL_RenderCopy(renderer, texture, NULL, NULL);
			SDL_RenderPresent(renderer);
			/* --- DRAW WIN MESSAGE --- */
			g->clearGrid();
			s->applySurface(508,15,g);
			/* --- CLEAR SCREEN FOR NEW GAME--- */

			counter = 0;
			defang(strategies,g); //See debugSnake.h
		}

		if (SDL_PollEvent(&e)) /* --- EVENTS --- */
		{
			if(e.key.keysym.sym == SDLK_ESCAPE) //escape key exits
				running = false;

			if(ingame) //for debugging
				{
					switch (e.key.keysym.sym) {	
					case SDLK_RIGHT:
						if (delay < 0)
						{
							g->changeDirection(0,true);
							delay = 6;
						}
						break;
					case SDLK_LEFT:
						if (delay < 0)
						{
							g->changeDirection(0,false);
							delay = 6;
						}
						break;
					}
				}

			menuButton->showMenu(*s); //display menu
			menuButton->handleMenu(e); //handle menu events
		}
		/*if(reset)
		{
			delete g;
			g = new Grid(gin);
			reset = false;
		}*/

		//Regulates Frame rate, pauses frame if too fast

		delay--;
}

int main()
{

    const int FRAMES_PER_SECOND = 30; 


	/* --- FRAME RATE --- */

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{

        return 1;
	}

	if (!loadResources())
		return 2;

	if (!initGraphics())
        	return 3;

	//if (!initSound()) //Song removed to avoid getting sued.
		//return 4;

	if (!initMenu())
		return 5;


	initStrategies(strategies,g); //See debugSnake.h

	//manage spawning intervals
	emscripten_set_main_loop(loop, 60, 1);
        
    cleanUp();

	system("Pause"); //For debugging purposes. Delete later
	
	return 0;
}


bool loadResources()
{
	if( TTF_Init() == -1 )
        return false;  

	font = TTF_OpenFont("assets/ABBERANC.TTF", 60);
	if( font == NULL )
        return false;

	background = IMG_Load("assets/background.png");
	if( background == NULL )
        return false;

	return true;
}

bool initGraphics() /* DOCUMENTATION UPON REQUEST */
{   

	window = SDL_CreateWindow(NULL, 50, 50, 1280, 720, SDL_WINDOW_BORDERLESS | SDL_WINDOW_OPENGL);
	renderer = SDL_CreateRenderer(window, -1, 0);
	texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 1280, 720);

	if(window == NULL)
		return false;

    s = new Surface(SDL_GetWindowSurface(window));

    if (s->getSurface() == NULL)
        return false;

	s->applySurface(0,0,background,&background->clip_rect);

	gin = SDL_CreateRGBSurface(0, s->getSurface()->w - 530, s->getSurface()->h - 30, 32, 0, 0, 0, 0);

	if (gin == NULL)
        return false;

	g = new Grid(gin,2);

	s->applySurface(508,15,g);

	SDL_UpdateTexture(texture, NULL, s->getSurface()->pixels, 1280 * sizeof (Uint32));

    return true;
}

bool initMenu() /* DOCUMENTATION UPON REQUEST */
{

	menuButton = new Menu(150,120,250,100);

    //DEV NOTE: Modify flags
    menuButton->addButton("assets/ButtonStart.png",ingame,s->getSurface());
	//menuButton->getButton(0)->addSwap("ButtonPause.png"); //fixing
	menuButton->addButton("assets/ButtonSelect.png",selection,s->getSurface());
	menuButton->addButton("assets/ButtonExit.png",running,s->getSurface());

	jar = SDL_CreateRGBSurface(0, 300, 150, 32, 0, 0, 0, 0);
	logo();

	snakeJar = new Grid(jar,1,SDL_MapRGB(gin->format,255,255,255));
	charmer = new Strategy(snakeJar->grabSnake(0),snakeJar);

	return true;
}

bool initSound() /* DOCUMENTATION UPON REQUEST */
{
	int audioRate = 22050;
	Uint16 audioFormat = AUDIO_S16SYS;
	int audioChannels = 2;
	int audioBuffers = 4096;
 
	//if(Mix_OpenAudio(audioRate, audioFormat, audioChannels, audioBuffers) != 0) 
		//return false;

	//bgm = Mix_LoadWAV("Rising.wav");
	//if(bgm == NULL) 
	//	return false;

	//if(Mix_PlayChannel(-1, bgm, -1) == -1)
	//	return false;
	return true;
}

void cleanUp() /* DOCUMENTATION UPON REQUEST */
{
	SDL_DestroyTexture(texture);
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_FreeSurface(gin);
	SDL_FreeSurface(jar);
	SDL_FreeSurface(background);
	//Mix_FreeChunk(bgm);

    SDL_Quit();
}

void logo() //Nefarious plot for world domination
{
	for(int i = 0; i < 33; i++)
	{
		blocks[i].w = 10;
		blocks[i].h = 10;
	}

	blocks[0].x = 230;
	blocks[0].y = 20;
	
	if (rand() % 33 != 18) //Trick or Treat Bitch!
	{
		blocks[1].x = 220;
		blocks[1].y = 30;
	}

	blocks[2].x = 230;
	blocks[2].y = 50;
	
	blocks[3].x = 250;
	blocks[3].y = 40;
	
	blocks[4].x = 220;
	blocks[4].y = 40;
	
	blocks[5].x = 240;
	blocks[5].y = 90;
	
	blocks[6].x = 220;
	blocks[6].y = 80;
	
	blocks[7].x = 230;
	blocks[7].y = 70;
	
	blocks[8].x = 230;
	blocks[8].y = 100;
	
	blocks[9].x = 190;
	blocks[9].y = 90;

	blocks[10].x = 200;
	blocks[10].y = 20;

	blocks[11].x = 210;
	blocks[11].y = 30;

	blocks[12].x = 190;
	blocks[12].y = 20;

	blocks[13].x = 180;
	blocks[13].y = 30;

	blocks[14].x = 190;
	blocks[14].y = 50;

	blocks[15].x = 160;
	blocks[15].y = 40;

	blocks[16].x = 170;
	blocks[16].y = 20;

	blocks[17].x = 140;
	blocks[17].y = 30;

	blocks[18].x = 150;
	blocks[18].y = 20;

	blocks[19].x = 130;
	blocks[19].y = 40;

	blocks[20].x = 150;
	blocks[20].y = 50;

	blocks[21].x = 140;
	blocks[21].y = 100;
	
	blocks[22].x = 130;
	blocks[22].y = 90;

	blocks[23].x = 150;
	blocks[23].y = 120;
	
	blocks[24].x = 160;
	blocks[24].y = 90;

	blocks[25].x = 110;
	blocks[25].y = 110;

	blocks[26].x = 120;
	blocks[26].y = 40;

	blocks[27].x = 40;
	blocks[27].y = 50;

	blocks[28].x = 50;
	blocks[28].y = 40;

	blocks[29].x = 130;
	blocks[29].y = 50;

	blocks[30].x = 40;
	blocks[30].y = 110;

	blocks[31].x = 50;
	blocks[31].y = 120;

	blocks[32].x = 100;
	blocks[32].y = 40;

	SDL_FillRects(jar, blocks, 33, SDL_MapRGB(gin->format,0,255,0));
}
