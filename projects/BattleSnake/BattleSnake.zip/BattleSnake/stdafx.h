/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * stdafx.h
*/

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#  include <emscripten.h>
#include <iostream>
#include <string>
#include "SDL_image.h"
#include "Menu.h"
#include "Strategy.h"

// TODO: reference additional headers your program requires here
