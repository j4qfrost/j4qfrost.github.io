/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Menu.h
*/

#ifndef MENU_H
#define	MENU_H

#include "Button.h"

class Menu
{
public:
    Menu(int boxX, int boxY, int boxW, int boxH);
	/**
		This constructor initializes the size of each Button and location of the Menu
		that will be draw to and SDL_Surface.
	*/

    ~Menu();

	Button* getButton(int i) const;
	/**
		Returns the ith Button object of member buttonList.

		@param i - The index of buttonList to be accessed.
		@return "" "" ""
	*/

	SDL_Rect* getOffset() const;
	/**
		Returns the region where the Menu will be draw on and where events will be handle.

		@return "" "" ""
	*/
    
    void addButton(const string& file, bool& flag, const SDL_Surface* destination);
    /**
		Adds a Button to the member buttonList. This function also adjusts the affected area.

		@param file - This supplies the source for the Button images.
		@param flag - This is the boolean that the Button will handle as a switch.
		@param destination - This is the SDL_Surface that the Button will be drawn to.
	*/
    
    void showMenu(Surface& destination);
    /**
		This draws the Menu onto the Surface destination. It calls show() on all Button objects
		in member buttonList. ~see Button class

		@param destination - The Surface object that contains the SDL_Surface to draw to.
	*/
    
    void handleMenu(const SDL_Event& e);
    /**
		This handles events for the affected region set aside by the member offset. It calls
		handleEvent() on all Button objects in member buttonList. ~see Button class

		@param e - The event to be evaluated.
	*/

private:
    Button* buttonList; //list of Button objects
    SDL_Rect* offset; //region the menu occupies
    int w; //width of each button
    int h; //height of each button
    unsigned int count; //number of buttons
    unsigned int capacity; //max number of buttons - subject to change
};

#endif	/* MENU_H */

