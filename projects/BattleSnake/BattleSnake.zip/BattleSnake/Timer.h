/**
 * @auhtor		Justin Chen
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Timer.h
*/

#ifndef TIMER_H
#define TIMER_H

class Timer
{
public: 
	//Initializes variables 
	Timer();

	//The various clock actions
	void start(); 
	void stop();

	//Gets the timer's time 
	int getTicks() const;
private: 
	//The clock time when the timer started 
	int startTicks;
	//The timer status 
	bool started; 
};

#endif