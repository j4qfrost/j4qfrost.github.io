/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Button.h
*/

#ifndef BUTTON_H
#define	BUTTON_H

#include "Surface.h"

using namespace std;

class Button
{
public:
	Button();
	/**
		This constructor initializes the member surface to a 1280x720 32 bit SDL_Surface.
		Avoid using it unless creating an array of Surfaces. This constructor was mainly
		created for the purpose of inheritance. ~see Menu, Grid classes
	*/

    Button(const string& file, const SDL_Surface* destination);
	/**
		This constructor is used better if you want to load your resources right away
		but don't immediately know the location you want to draw to. For the purposes
		of Battle Snake, this constructor will not be used.
	*/

    Button(int x, int y, int w, int h, bool& f, const string& file, const SDL_Surface* destination);
	/**
		This constructor is used if you know exactly where you want to draw the Button to the
		screen. Menu handles the location and size for the Button, so this constructor won't be
		used there. This constructor was originally used because the Menu class did not exist.
	*/

    ~Button();
    
	SDL_Surface* getSource() const;
	/**
		Returns the source picture that the button draws from.

		@return "" "" ""
	*/

    void setSource(const string& file, const SDL_Surface* destination);
    /**
		This loads a source image for the Button and formats it to the SDL_Surface destination.

		@param file - Name of the file to be loaded.
		@param destination - The destination to be drawn to.
	*/
    
    void setCoordinates(int x, int y);
    /**
		Sets the coordinates of the Button.

		@param x,y - The new coordinates.
	*/
    
    void setBounds(int w, int h);
    /**
		Sets the size of the Button.

		@param w,h - The new affected range set aside to be drawn on and handle events for.
	*/
    
    void setFlag(bool& f);
    /**
		Sets the flag to be switched on and off.

		@param f - Boolean to be switched on and off.
	*/
    
    void setParams(int x, int y, int w, int h, bool& f, const string& file, const SDL_Surface* destination);
    /**
		Calls all set functions and passes its parameters

		@param ~see previous
	*/

	void addClip(int x, int y, int w, int h);
	/**
		Adds another clip from the source image. x and y will vary on the size of the clip.

		@param ~see previous
	*/

	void addSwap(const string& file);
	//Updating
    
    void handleEvent(const SDL_Event& e);
    /**
		Hnadles the member flag. If the affected region is clicked on, the flag is switched.

		@param e - The even to be evaluated.
	*/
    
    void show(Surface& destination);
    /**
		Draws the Button to the destination Surface.

		@param destination - This holds the SDL_Surface to be drawn to.
	*/

private:
	SDL_Rect* clip; //crop for button image
	SDL_Rect* clips; //areas for cropping the image
    SDL_Rect bounds; //stores clickable area and size
    bool* flag; //control flag
	SDL_Surface* source; //source image
	SDL_Surface* swap;
    unsigned int count;  //number of crops
    unsigned int capacity;
};

#endif

