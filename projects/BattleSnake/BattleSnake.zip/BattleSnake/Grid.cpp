#include "stdafx.h"
#include "Grid.h"

Grid::Grid()
{
}

Grid::Grid(SDL_Surface* s, int nSnakes): Surface(s)
{
	SDL_Rect snakeBox = SDL_Rect();
	snakeBox.x = 0;
	snakeBox.y = 0;
	snakeBox.w = s->w;
	snakeBox.h = s->h;

	savedSize = nSnakes;
	initPixels();

	arenaStart = new int [nSnakes];
	arenaStart[0] = 200;
	arenaStart[1] = 200;
	arenaStart[2] = snakeBox.w - 200;
	arenaStart[3] = snakeBox.h - 200;

	srand(time(NULL));

	for(int i = 0; i < nSnakes; i++)
	{
		snakes.push_back(new Snake(arenaStart[2 * i], arenaStart[2 * i], snakeBox, rand() % 4, colorType[i + 1], false));
	}
}

Grid::Grid(SDL_Surface* s, int nSnakes, Uint32 color): Surface(s)
{
	SDL_Rect snakeBox = SDL_Rect();
	snakeBox.x = 0;
	snakeBox.y = 0;
	snakeBox.w = s->w;
	snakeBox.h = s->h;

	savedSize = nSnakes;
	initPixels();

	for(int i = 0; i < nSnakes; i++)
	{
		snakes.push_back(new Snake(50, 30, snakeBox, i, color, true));
	}
}

bool Grid::checkCollision()
{
	bool collided = false;
	unsigned int length = snakes.size();
	SDL_Rect* vision = new SDL_Rect[snakes.size()];
	unsigned int i = 0;
	while(i < length)
	{
		switch (snakes[i]->checkCollision(colorType,this)) {
		case 0:
			snakes[i]->setScale(1);
			collided = true;
			break;
		case 1:
			snakes[i]->growSnake();
			snakes[i]->move();
			snakes[i]->growSnake();
			snakes[i]->move();
			snakes[i]->growSnake();
			snakes[i]->move();
			break;
		case 2:
			vision[i] = snakes[i]->getLineOfSight();
			bool same = false;
			unsigned int j = 0;
			while(j < i && !same)
			{
				if (vision[j].x == vision[i].x && vision[j].y == vision[i].y)
				{
					snakes[i]->setScale(1);
					snakes[j]->setScale(1);
					same = true;
					collided = true;
				}
				j++;
			}
			break;
		}
		

		i++;
	}
	return collided;
}

Snake* Grid::grabSnake(int i) const
{
	return snakes[i];
}

unsigned int Grid::getSavedSize() const
{
	return savedSize;
}

void Grid::initPixels()
{
	SDL_Surface* s = this->getSurface();
	Uint32* pixels = (Uint32*)s->pixels;

	colorType = new Uint32 [5];
	colorType[0] = SDL_MapRGB(s->format, 0, 0, 0);
	colorType[1] = SDL_MapRGB(s->format, 0, 0, 255);
	colorType[2] = SDL_MapRGB(s->format, 255, 0, 0);
	colorType[3] = SDL_MapRGB(s->format, 0, 255, 0);
	colorType[4] = SDL_MapRGB(s->format, 255, 255, 255);

	if (savedSize > 1)
	{
		SDL_Rect* block = new SDL_Rect;
		block->w = 10;
		block->h = 10;
		block->y = 0;
		int i = 0;
		while(i < s->w)
		{
			block->x = i;
			SDL_FillRect(s,block,colorType[3]);
			i += 10;
		}
		int j = 10;
		while(j < s->h - 10)
		{
			block->y = j;
			SDL_FillRect(s,block,colorType[3]);
			j += 10;
		}
		block->y = j;
		while(i > 0)
		{
			block->x = i;
			SDL_FillRect(s,block,colorType[3]);
			i -= 10;
		}
		block->x = i;
		while(j > 0)
		{
			block->y = j;
			SDL_FillRect(s,block,colorType[3]);
			j -= 10;
		}
	}
}

void Grid::drawSnakes()
{
	for(unsigned int i = 0; i < snakes.size(); i++)
		snakes[i]->drawSnake(this);
}

void Grid::moveSnakes()
{
	for(unsigned int i = 0; i < snakes.size(); i++)
		snakes[i]->move();
}

void Grid::changeDirection(int i, bool right)
{
	if (right)
		snakes[i]->moveRight();
	else
		snakes[i]->moveLeft();
}

void Grid::growSnake(int i)
{
	snakes[i]->growSnake();
}

void Grid::dropStuff()
{
	int x = (rand() % this->getSurface()->w) / 10 * 10;
	int y = (rand() % this->getSurface()->h) / 10 * 10;

	Uint32* pixels = (Uint32*)this->getSurface()->pixels;

	SDL_Rect offset;
	offset.w = 10;
	offset.h = 10;
	offset.x = x;
	offset.y = y;
	if (pixels[((y + 1) * this->getSurface()->w) + x + 1] == colorType[0])
		SDL_FillRect(this->getSurface(), &offset, colorType[rand() % 2 + 3]);
}

void Grid::clearGrid()
{
	SDL_Rect* clear = new SDL_Rect;
	clear->x = 10;
	clear->y = 10;
	clear->w = this->getSurface()->w - 20;
	clear->h = this->getSurface()->h - 20;

	SDL_FillRect(this->getSurface(),clear,0);
	
	throwSnakes();

	for(unsigned int i = 0; i < savedSize; i++)
	{
		snakes.push_back(new Snake(arenaStart[2 * i],arenaStart[2 * i + 1],
						this->getSurface()->clip_rect,rand() % 4, colorType[i + 1], false));
	}
}

void Grid::addSnake(Snake* snake)
{
	snakes.push_back(snake);
	savedSize++;
}

void Grid::throwSnakes()
{
	for(vector<Snake*>::iterator i = snakes.begin(); i != snakes.end(); i++)
	{
		*i = NULL;
	}
	snakes.clear();
}

Grid::~Grid()
{
	throwSnakes();
	delete [] colorType;
	colorType = NULL;
}