/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Surface.h
*/

#ifndef SURFACE_H
#define	SURFACE_H

#include "SDL.h"
#undef main

class Surface
{
public:
    Surface();
	/**
		This constructor initializes the member surface to a 1280x720 32 bit SDL_Surface.
		Avoid using it unless creating an array of Surfaces. This constructor was mainly
		created for the purpose of inheritance. ~see Grid class
	*/

	Surface(SDL_Surface* s);
	/**
		This constructor sets member variable surface to pointer s. This is more flexible
		and generally better to use, since you will be calling SDL_FillRect many times.
	*/

    Surface(int w, int h, int bpp);
	/**
		This constructor sets member variable surface to an SDL_Surface of width w and height h.
		If you plan to draw only SDL_Surfaces onto surface, this would be ideal.
	*/

    ~Surface();

    SDL_Surface* getSurface() const;
	/**
		Returns the member variable surface.

		@return "" "" ""
	*/

	void setSurface(SDL_Surface* s);
	/**
		Returns the member variable surface.

		@param s - The new surface to be assigned to member surface.
	*/
    
	void applySurface(int x, int y, const Surface* s);
	/**
		This blits the surface of another Surface object to the member surface. This is
		better for applying whole SDL_Surfaces.

		@param x,y - Coordinates to which s is to be applied to.
		@param s - The Surface object containing the surface to be applied.
	*/

    void applySurface(int x, int y, SDL_Surface* src, const SDL_Rect* clip);
	/**
		This blits the surface of another Surface object to the member surface. This is
		better for applying clips of SDL_Surfaces.

		@param x,y - Coordinates to which s is to be applied to.
		@param src - The source that is used to display parts of an image.
		@param clip - The location used to section off the source.
	*/
private:
    SDL_Surface* surface; //SDL_Surface to be drawn in window
};

#endif

