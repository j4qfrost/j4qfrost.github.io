#include "stdafx.h"
#include "Timer.h"


Timer::Timer()
{
	startTicks = 0;
	started = true;

}

void Timer::start()
{
	started = true;
	startTicks = SDL_GetTicks();
}

int Timer::getTicks() const
{
	return (SDL_GetTicks() - startTicks);
}


