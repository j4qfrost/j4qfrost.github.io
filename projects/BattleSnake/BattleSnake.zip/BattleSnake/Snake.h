/**
 * @auhtor		AnhQuan Nguyen		xxaq10xx@gmail.com
 * @author		Justin Le
 * @group		O(1) Algorithms
 * 
 * @version	Oct. 29, 2013
 * 
 * BATTLE_SNAKE
 * Snake.h
*/

#ifndef SNAKE_H
#define SNAKE_H

#include "Surface.h"

class Node
{
public:
	Node(){}
	Node (int theDataX, int theDataY, Node *previous, Node *next):x(theDataX),y(theDataY), nextLink(next), previousLink(previous) {}    

	int getX( ) const { return x; }
	int getY( ) const { return y; }	
	void setX(int nx) { x = nx; }
    void setY(int ny) { y = ny; }
	
    Node *getNextLink( ) const { return nextLink; }
    Node *getPreviousLink( ) const { return previousLink; }
	void setNextLink(Node *pointer) { nextLink = pointer; }
    void setPreviousLink(Node *pointer) { previousLink = pointer; }
	
	~Node(){}
private:
	int x;
	int y;
    Node* nextLink;
    Node* previousLink;	//pointer that points to next node
};

class Snake
{
public:
	Snake();
	/**
		This constructor was implemented for simmple initialization of pointers.
		It is likely that I will delete this later.
	*/

	Snake(int x, int y, SDL_Rect b, unsigned int d, Uint32 color, bool w);
	/**
		This constructor is more useful in general.
	*/

	~Snake();

	void setCoordinates(int x, int y);
	/**
		Sets the starting position of the Snake. This should only be used while initializing the Snake.
		If you misuse this fucntion, the game will do some weird stuff. Go nuts.

		@param x,y - New coordinates of the head and the tail of the Snake.
	*/

	void setBounds(SDL_Rect b);
	/**
		Sets the region where the Snake is moving in. There are some naughty things you can do with this
		function.

		@param b - Region where the Snake wil be draw and tested.
	*/

	void setDirection(unsigned int d);
	/**
		Sets the direction of the Snake.

		@param d - Direction the Snake is to be set at.
	*/

	void setScale(Uint32 color);
	/**
		You will absolutely not need to touch this. Feel free to have fun with it though.

		@param color - New color of the Snake.
	*/

	void setParams(int x, int y, SDL_Rect b, unsigned int d, Uint32 color);
	/**
		Calls the set functions.
	*/

	void growSnake();
	/**
		Sets member grow to true, which tells the move() function to skip deletion of a Node.
	*/

	void moveLeft();
	/**
		Changes the direction left relative to the current direction i.e. "three rights make a left".
	*/

	void moveRight();
	/**
		Changes the direction right relative to the current direction i.e. "three rights make a left".
	*/

	void move();
	/**
		Moves the Snake by setting the head to a new Node with new coordinates and deleting the last Node.
	*/
	
	void drawSnake(const Surface* destination);
	/**
		Draws a Snake onto a the SDL_Surface held by destination.

		@param desitination - Surface that holds the SDL_Surface to draw to.
	*/

	void drawTile(int x, int y, const Surface* destination, Uint32 color);
	/**
		Helper function for drawSnake(). This draws the blocks individually.

		@param x,y - Coordinates to be drawn at.
		@param destination - See above.
		@oaram color - Indicates the color to be drawn.
	*/

	void destroySnake();
	/**
		Deletes all the Nodes in the linked list that holds the coordinates of the Snake.
	*/
	
	Node* getHead() const;
	/**
		Returns the member head.

		@return The head which holds the coordinates of the first Node of coordinates.
	*/

	Node* getRattle() const;
	/**
		Returns the member rattle.

		@return The rattle which holds the coordinates of the last Node of coordinates.
	*/

	int checkCollision(const Uint32* colorType, const Surface* s);
	/**
		Returns a condition that is interpreted by the Grid class checkCollision(). see Grid class

		@param colorType - The array of colors to check for. This is normally provided by the supporting Grid.
		@param s - Since the collision is implemented graphically, this provides the pixels to be tested at a
				   certain coordinate.
		@return The flag to be interpreted by the supporting Grid class.
	*/

	int getLength() const;
	/**
		Returns the current length of the Snake.

		@return "" "" ""
	*/

	int getDirection() const;
	/**
		Returns the current direction of the Snake.
	*/

	Uint32 getPixel(const SDL_Surface* s, int x, int y) const;
	/**
		Returns the pixel color at a specified coordinate. This was originally implemented as a helper for
		checkCollision(const Uint32*,const Surface*) and can be used for more creative purposes.

		@param s - This holds the SDL_Surface we want to get pixels from.
		@param x,y - Coordinates specified for grabbing the pixel color.
		@return The color of the pixel at the specified location.
	*/

	Uint32 getScale() const;
	/**
		Returns the color of the Snake.
	*/

	SDL_Rect getLineOfSight() const;
	/**
		Returns the next square the snake moves into.
	*/
private:
	unsigned int direction; // direction where snake head to	
	Node* head; //first Node of coordinates
	Node* rattle; //last
	SDL_Rect* bound; //playing area

	Uint32 scale; //stores the color of the Snake
	int length; //length of the Snake and linked list
	int maxLength; //caps the size of the Snake //currently @ 100
	int segmentSize; //size of each block

	bool init; //checks move() was run for the first time
	bool grow; //stores whether Snake needs to grow
	bool wrap; //does the Snake wrap around the screen
};

#endif

