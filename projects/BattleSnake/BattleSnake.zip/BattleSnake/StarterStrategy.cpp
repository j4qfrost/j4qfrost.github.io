#include "stdafx.h"
#include "StarterStrategy.h"