#include "stdafx.h"
#include "Strategy.h"

Strategy::Strategy()
{
	name = "Formula01";
}

Strategy::Strategy(Snake* dumbSnake, Grid* g)
{
	name = "Pungi";
	resultFlag = false;

	cobra = dumbSnake;
	grid = g;
}

void Strategy::setCobra(Snake* snake)
{
	cobra = snake;
}

void Strategy::setGrid(Grid* g)
{
	grid = g;
}

Snake* Strategy::getCobra() const
{
	return cobra;
}

bool Strategy::dodge(int direction, bool rightChecked) const
{
	Uint32 color = 0;
	switch (cobra->getDirection()) {
		case 0:
			color = cobra->getPixel(grid->getSurface(),  cobra->getHead()->getX() - 5, cobra->getHead()->getY());
			break;		
		case 1:
			color = cobra->getPixel(grid->getSurface(), cobra->getHead()->getX(), 10 + cobra->getHead()->getY());
			break;
		case 2:
			color = cobra->getPixel(grid->getSurface(),  10 + cobra->getHead()->getX(), cobra->getHead()->getY());
			break;
		case 3:
			color = cobra->getPixel(grid->getSurface(), cobra->getHead()->getX(), cobra->getHead()->getY() - 5);
			break;
		}
	if (!(color == 0 || color == SDL_MapRGB(grid->getSurface()->format,255,255,255)))
	{
		cobra->moveRight();
		if (!rightChecked)
			return dodge(cobra->getDirection(), !rightChecked);
		else
		{
			cobra->moveRight();
			return true; //Analyze flag
		}
	}
	return false; //Analyze flag
}

void Strategy::runStrategy()
{
	dodge(cobra->getDirection(),false);
}

void Strategy::changeName(const string& newName)
{
	name = newName;
}

void Strategy::burnSnake()
{
	delete cobra;
	cobra = NULL;
}

string Strategy::getName() const
{
	return name;
}

Uint32* Strategy::getPixels() const
{
	return (Uint32*)grid->getSurface()->pixels;
}

Strategy::~Strategy()
{
	burnSnake();
	delete grid;
	grid = NULL;
}