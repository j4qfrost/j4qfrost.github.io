/* 
 * File:   Sprite.cpp
 * Author: frosty
 * 
 * Created on January 19, 2014, 8:41 PM
 */

#include "Sprite.h"

Sprite::Sprite() {
}

Sprite::Sprite(const Sprite& orig) {
    
}

void* Sprite::getSource() const {
    return NULL;
}

void Sprite::setSource(const void* src) {
    
}

Sprite::~Sprite() {
}



