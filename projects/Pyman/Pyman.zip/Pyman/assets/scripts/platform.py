def movePlatform(x,y):
 if (y < 400):
  return (x+1,y+1)
 return (x,y)