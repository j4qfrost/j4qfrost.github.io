def bar():
	print("hi")
	return 0