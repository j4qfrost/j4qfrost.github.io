print("Hello, World!")
print(6+6)