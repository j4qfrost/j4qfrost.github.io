/*
 * Interface.cpp
 *
 *  Created on: Apr 27, 2014
 *      Author: frosty
 */

#include "Interface.h"

Interface::Interface() {
	// TODO Auto-generated constructor stub

}

int Interface::run(const char* runnable)
{
	return 0;
}

Interface::~Interface() {
	// TODO Auto-generated destructor stub
}

